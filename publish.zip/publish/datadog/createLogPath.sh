#!/bin/bash
set -euxo pipefail

mkdir -p /var/log/datadog/dotnet
chmod a+rwx /var/log/datadog/dotnet
